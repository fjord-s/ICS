/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ics;

/**
 *
 * @author Steve
 */
public class Users {
    Users(){}
    String role;
    int idNum;
    String fan;
    String password;
    String firstName;
    String lastName;
    int phoneNum;
    
    /*staff*/
    public Users(String role,int idnum, String password){
        this.role = role;
        this.idNum = idnum;
        this.password = password;
    }
    /*student*/
    public Users(String role,int idNum, String fan, String password){
        this.role = role;
        this.idNum = idNum;
        this.fan = fan;
        this.password = password;
           
    }
    /*guest*/
    public Users(String role, String firstName, String lastName, int phoneNum){
        this.role = role;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNum = phoneNum;
        
    }
    
}
